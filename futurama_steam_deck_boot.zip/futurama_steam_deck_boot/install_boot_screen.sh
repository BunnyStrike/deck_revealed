#!binbash

cp "$HOME/.local/share/Steam/steamui/movies/deck_startup.webm" "$HOME/.local/share/Steam/steamui/movies/deck_startup.webm.original"
cp ./deck_startup.webm "$HOME/.local/share/Steam/steamui/movies/deck_startup.webm"